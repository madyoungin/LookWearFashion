import React from "react";
import Dashboard from "./layout/dashboard/index";

function App() {
  return (
    <Dashboard />
    //<MyReview />
  );
}

export default App;
