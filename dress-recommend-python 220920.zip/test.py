import sys
print("시작!!!")
print(sys.argv[1])
print("종료!!!")
